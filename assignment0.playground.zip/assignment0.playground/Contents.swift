import UIKit


//function
func divide(x:Int, _ y:Int) -> Int{
    let ans = x/y
    return ans
}

//variables
//values can be changed
var result : Int
result = 1
var result1 = 1
result1 = 3

//value can't be changed
let ans : Int
ans = divide(6,2)



//function with external parameter name, different internal and external names, void function
func showAgeName (age: Int, name x: String, color: String) ->()
{
    print("\(color) cat named \(x) is \(age) year(s) old")
}
showAgeName(4, name:"Bob", color:"Brown")//all parameters except age are externalized


//enums
enum Animal{
    case Dog
    case Cat
    case Bunny
}
var dog1 : Animal
dog1 = .Dog


//class, computed variable, setter observer
class Cat{
    
    
    private var _isBlack = false
    
    var isBlack : Bool{
        get{
            return self._isBlack
        }
        set{
            self._isBlack = newValue
        }
    }
    
    //setter observer
    var age = 0 {
        willSet
        {
            print("About to set cat age to \(newValue)")
        }
        didSet
        {
            print("Set cat age from \(oldValue) to \(self.age)")
        }
    }
}


//anonymous function, define and call
//input parameter for showAge is a function that returns an integer = dog's age in dog years
func showAge( inDogYears: (age:Int) -> Int) -> Void
{
    let printAge = inDogYears(age:4)
    print("Dog's age is \(printAge) years")
}

showAge{
    (humanYears: Int) -> Int in
    return humanYears+4
}


//variadic parameter
//number of input parameters can vary
func repeatStrings(arr:String ...) -> ()
{
    for x in arr {print(x)}
}
repeatStrings("david", "jon", "bob")
repeatStrings("name1", "name2", "name3", "name4")




//modifiable parameter
func changeOld(inout isOld: Bool, _ age: Int) -> () {
    if(age<=5){
        isOld = false
    }
    else{
        isOld = true
    }
}
var old = true
changeOld(&old, 2)
print(old)



//default parameter values
//useless example because I couldn't think of a better one
func multiply(x:Int, y:Int = 3) -> Int
{
    return x*y
}
print(multiply(4))
print(multiply(4, y:2))






//computed initializer
let age = 5
let isOld : Bool = {
    if age>4 {
        return true
    }
    else {
        return false
    }
}()





//tuple
let (name1, name2) = ("harry", "bob")
name1
name2


//range
for i in 1...10 {
    print(i)
}
